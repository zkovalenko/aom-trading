#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private AOM_Trading.aomADPSignal[] cacheaomADPSignal;
		private AOM_Trading.aomManualStrategy[] cacheaomManualStrategy;
		private AOM_Trading.aomMarketStrAndBBWaves[] cacheaomMarketStrAndBBWaves;
		private AOM_Trading.aomMAX[] cacheaomMAX;
		private AOM_Trading.aomMIN[] cacheaomMIN;
		private AOM_Trading.aomRbrDbdSignal[] cacheaomRbrDbdSignal;
		private AOM_Trading.aomSDZones[] cacheaomSDZones;

		
		public AOM_Trading.aomADPSignal aomADPSignal(bool enLongTrade, bool enShortTrade, bool enTrendReversal, bool enTrendContinuation, bool enNoiseState, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return aomADPSignal(Input, enLongTrade, enShortTrade, enTrendReversal, enTrendContinuation, enNoiseState, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public AOM_Trading.aomManualStrategy aomManualStrategy(bool enGlobalTL, double intTLOffset, Brush tLSColor, Brush tLLColor, bool enADP, bool enSoM, bool enShortTrade, bool enLongTrade, bool enRBRDBDState, bool enTL, bool enSZ, bool alertsOn, string buySoundAlert, string sellSoundAlert, int contractSize, NinjaTrader.NinjaScript.Indicators.AOM_Trading.E_MyOrderType myOrderType, double entryOffset)
		{
			return aomManualStrategy(Input, enGlobalTL, intTLOffset, tLSColor, tLLColor, enADP, enSoM, enShortTrade, enLongTrade, enRBRDBDState, enTL, enSZ, alertsOn, buySoundAlert, sellSoundAlert, contractSize, myOrderType, entryOffset);
		}

		public AOM_Trading.aomMarketStrAndBBWaves aomMarketStrAndBBWaves(int iSwingStrength, bool enBarCounting, bool enSwingCounting, bool enSwingVisibility, bool enWaveVisibility, bool enSupportResistanceVisibility, bool enTouchedLine, bool enBrokenLine)
		{
			return aomMarketStrAndBBWaves(Input, iSwingStrength, enBarCounting, enSwingCounting, enSwingVisibility, enWaveVisibility, enSupportResistanceVisibility, enTouchedLine, enBrokenLine);
		}

		public AOM_Trading.aomMAX aomMAX(int period)
		{
			return aomMAX(Input, period);
		}

		public AOM_Trading.aomMIN aomMIN(int period)
		{
			return aomMIN(Input, period);
		}

		public AOM_Trading.aomRbrDbdSignal aomRbrDbdSignal(bool enLongTrade, bool enShortTrade, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return aomRbrDbdSignal(Input, enLongTrade, enShortTrade, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public AOM_Trading.aomSDZones aomSDZones()
		{
			return aomSDZones(Input);
		}


		
		public AOM_Trading.aomADPSignal aomADPSignal(ISeries<double> input, bool enLongTrade, bool enShortTrade, bool enTrendReversal, bool enTrendContinuation, bool enNoiseState, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			if (cacheaomADPSignal != null)
				for (int idx = 0; idx < cacheaomADPSignal.Length; idx++)
					if (cacheaomADPSignal[idx].enLongTrade == enLongTrade && cacheaomADPSignal[idx].enShortTrade == enShortTrade && cacheaomADPSignal[idx].enTrendReversal == enTrendReversal && cacheaomADPSignal[idx].enTrendContinuation == enTrendContinuation && cacheaomADPSignal[idx].enNoiseState == enNoiseState && cacheaomADPSignal[idx].SoundAlertsOn == soundAlertsOn && cacheaomADPSignal[idx].FileNameBuySound == fileNameBuySound && cacheaomADPSignal[idx].FileNameSellSound == fileNameSellSound && cacheaomADPSignal[idx].EqualsInput(input))
						return cacheaomADPSignal[idx];
			return CacheIndicator<AOM_Trading.aomADPSignal>(new AOM_Trading.aomADPSignal(){ enLongTrade = enLongTrade, enShortTrade = enShortTrade, enTrendReversal = enTrendReversal, enTrendContinuation = enTrendContinuation, enNoiseState = enNoiseState, SoundAlertsOn = soundAlertsOn, FileNameBuySound = fileNameBuySound, FileNameSellSound = fileNameSellSound }, input, ref cacheaomADPSignal);
		}

		public AOM_Trading.aomManualStrategy aomManualStrategy(ISeries<double> input, bool enGlobalTL, double intTLOffset, Brush tLSColor, Brush tLLColor, bool enADP, bool enSoM, bool enShortTrade, bool enLongTrade, bool enRBRDBDState, bool enTL, bool enSZ, bool alertsOn, string buySoundAlert, string sellSoundAlert, int contractSize, NinjaTrader.NinjaScript.Indicators.AOM_Trading.E_MyOrderType myOrderType, double entryOffset)
		{
			if (cacheaomManualStrategy != null)
				for (int idx = 0; idx < cacheaomManualStrategy.Length; idx++)
					if (cacheaomManualStrategy[idx].enGlobalTL == enGlobalTL && cacheaomManualStrategy[idx].intTLOffset == intTLOffset && cacheaomManualStrategy[idx].TLSColor == tLSColor && cacheaomManualStrategy[idx].TLLColor == tLLColor && cacheaomManualStrategy[idx].enADP == enADP && cacheaomManualStrategy[idx].enSoM == enSoM && cacheaomManualStrategy[idx].enShortTrade == enShortTrade && cacheaomManualStrategy[idx].enLongTrade == enLongTrade && cacheaomManualStrategy[idx].enRBRDBDState == enRBRDBDState && cacheaomManualStrategy[idx].enTL == enTL && cacheaomManualStrategy[idx].enSZ == enSZ && cacheaomManualStrategy[idx].AlertsOn == alertsOn && cacheaomManualStrategy[idx].BuySoundAlert == buySoundAlert && cacheaomManualStrategy[idx].SellSoundAlert == sellSoundAlert && cacheaomManualStrategy[idx].contractSize == contractSize && cacheaomManualStrategy[idx].myOrderType == myOrderType && cacheaomManualStrategy[idx].entryOffset == entryOffset && cacheaomManualStrategy[idx].EqualsInput(input))
						return cacheaomManualStrategy[idx];
			return CacheIndicator<AOM_Trading.aomManualStrategy>(new AOM_Trading.aomManualStrategy(){ enGlobalTL = enGlobalTL, intTLOffset = intTLOffset, TLSColor = tLSColor, TLLColor = tLLColor, enADP = enADP, enSoM = enSoM, enShortTrade = enShortTrade, enLongTrade = enLongTrade, enRBRDBDState = enRBRDBDState, enTL = enTL, enSZ = enSZ, AlertsOn = alertsOn, BuySoundAlert = buySoundAlert, SellSoundAlert = sellSoundAlert, contractSize = contractSize, myOrderType = myOrderType, entryOffset = entryOffset }, input, ref cacheaomManualStrategy);
		}

		public AOM_Trading.aomMarketStrAndBBWaves aomMarketStrAndBBWaves(ISeries<double> input, int iSwingStrength, bool enBarCounting, bool enSwingCounting, bool enSwingVisibility, bool enWaveVisibility, bool enSupportResistanceVisibility, bool enTouchedLine, bool enBrokenLine)
		{
			if (cacheaomMarketStrAndBBWaves != null)
				for (int idx = 0; idx < cacheaomMarketStrAndBBWaves.Length; idx++)
					if (cacheaomMarketStrAndBBWaves[idx].iSwingStrength == iSwingStrength && cacheaomMarketStrAndBBWaves[idx].enBarCounting == enBarCounting && cacheaomMarketStrAndBBWaves[idx].enSwingCounting == enSwingCounting && cacheaomMarketStrAndBBWaves[idx].enSwingVisibility == enSwingVisibility && cacheaomMarketStrAndBBWaves[idx].enWaveVisibility == enWaveVisibility && cacheaomMarketStrAndBBWaves[idx].enSupportResistanceVisibility == enSupportResistanceVisibility && cacheaomMarketStrAndBBWaves[idx].enTouchedLine == enTouchedLine && cacheaomMarketStrAndBBWaves[idx].enBrokenLine == enBrokenLine && cacheaomMarketStrAndBBWaves[idx].EqualsInput(input))
						return cacheaomMarketStrAndBBWaves[idx];
			return CacheIndicator<AOM_Trading.aomMarketStrAndBBWaves>(new AOM_Trading.aomMarketStrAndBBWaves(){ iSwingStrength = iSwingStrength, enBarCounting = enBarCounting, enSwingCounting = enSwingCounting, enSwingVisibility = enSwingVisibility, enWaveVisibility = enWaveVisibility, enSupportResistanceVisibility = enSupportResistanceVisibility, enTouchedLine = enTouchedLine, enBrokenLine = enBrokenLine }, input, ref cacheaomMarketStrAndBBWaves);
		}

		public AOM_Trading.aomMAX aomMAX(ISeries<double> input, int period)
		{
			if (cacheaomMAX != null)
				for (int idx = 0; idx < cacheaomMAX.Length; idx++)
					if (cacheaomMAX[idx].Period == period && cacheaomMAX[idx].EqualsInput(input))
						return cacheaomMAX[idx];
			return CacheIndicator<AOM_Trading.aomMAX>(new AOM_Trading.aomMAX(){ Period = period }, input, ref cacheaomMAX);
		}

		public AOM_Trading.aomMIN aomMIN(ISeries<double> input, int period)
		{
			if (cacheaomMIN != null)
				for (int idx = 0; idx < cacheaomMIN.Length; idx++)
					if (cacheaomMIN[idx].Period == period && cacheaomMIN[idx].EqualsInput(input))
						return cacheaomMIN[idx];
			return CacheIndicator<AOM_Trading.aomMIN>(new AOM_Trading.aomMIN(){ Period = period }, input, ref cacheaomMIN);
		}

		public AOM_Trading.aomRbrDbdSignal aomRbrDbdSignal(ISeries<double> input, bool enLongTrade, bool enShortTrade, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			if (cacheaomRbrDbdSignal != null)
				for (int idx = 0; idx < cacheaomRbrDbdSignal.Length; idx++)
					if (cacheaomRbrDbdSignal[idx].enLongTrade == enLongTrade && cacheaomRbrDbdSignal[idx].enShortTrade == enShortTrade && cacheaomRbrDbdSignal[idx].SoundAlertsOn == soundAlertsOn && cacheaomRbrDbdSignal[idx].FileNameBuySound == fileNameBuySound && cacheaomRbrDbdSignal[idx].FileNameSellSound == fileNameSellSound && cacheaomRbrDbdSignal[idx].EqualsInput(input))
						return cacheaomRbrDbdSignal[idx];
			return CacheIndicator<AOM_Trading.aomRbrDbdSignal>(new AOM_Trading.aomRbrDbdSignal(){ enLongTrade = enLongTrade, enShortTrade = enShortTrade, SoundAlertsOn = soundAlertsOn, FileNameBuySound = fileNameBuySound, FileNameSellSound = fileNameSellSound }, input, ref cacheaomRbrDbdSignal);
		}

		public AOM_Trading.aomSDZones aomSDZones(ISeries<double> input)
		{
			if (cacheaomSDZones != null)
				for (int idx = 0; idx < cacheaomSDZones.Length; idx++)
					if ( cacheaomSDZones[idx].EqualsInput(input))
						return cacheaomSDZones[idx];
			return CacheIndicator<AOM_Trading.aomSDZones>(new AOM_Trading.aomSDZones(), input, ref cacheaomSDZones);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.AOM_Trading.aomADPSignal aomADPSignal(bool enLongTrade, bool enShortTrade, bool enTrendReversal, bool enTrendContinuation, bool enNoiseState, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomADPSignal(Input, enLongTrade, enShortTrade, enTrendReversal, enTrendContinuation, enNoiseState, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomManualStrategy aomManualStrategy(bool enGlobalTL, double intTLOffset, Brush tLSColor, Brush tLLColor, bool enADP, bool enSoM, bool enShortTrade, bool enLongTrade, bool enRBRDBDState, bool enTL, bool enSZ, bool alertsOn, string buySoundAlert, string sellSoundAlert, int contractSize, NinjaTrader.NinjaScript.Indicators.AOM_Trading.E_MyOrderType myOrderType, double entryOffset)
		{
			return indicator.aomManualStrategy(Input, enGlobalTL, intTLOffset, tLSColor, tLLColor, enADP, enSoM, enShortTrade, enLongTrade, enRBRDBDState, enTL, enSZ, alertsOn, buySoundAlert, sellSoundAlert, contractSize, myOrderType, entryOffset);
		}

		public Indicators.AOM_Trading.aomMarketStrAndBBWaves aomMarketStrAndBBWaves(int iSwingStrength, bool enBarCounting, bool enSwingCounting, bool enSwingVisibility, bool enWaveVisibility, bool enSupportResistanceVisibility, bool enTouchedLine, bool enBrokenLine)
		{
			return indicator.aomMarketStrAndBBWaves(Input, iSwingStrength, enBarCounting, enSwingCounting, enSwingVisibility, enWaveVisibility, enSupportResistanceVisibility, enTouchedLine, enBrokenLine);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(int period)
		{
			return indicator.aomMAX(Input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(int period)
		{
			return indicator.aomMIN(Input, period);
		}

		public Indicators.AOM_Trading.aomRbrDbdSignal aomRbrDbdSignal(bool enLongTrade, bool enShortTrade, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomRbrDbdSignal(Input, enLongTrade, enShortTrade, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomSDZones aomSDZones()
		{
			return indicator.aomSDZones(Input);
		}


		
		public Indicators.AOM_Trading.aomADPSignal aomADPSignal(ISeries<double> input , bool enLongTrade, bool enShortTrade, bool enTrendReversal, bool enTrendContinuation, bool enNoiseState, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomADPSignal(input, enLongTrade, enShortTrade, enTrendReversal, enTrendContinuation, enNoiseState, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomManualStrategy aomManualStrategy(ISeries<double> input , bool enGlobalTL, double intTLOffset, Brush tLSColor, Brush tLLColor, bool enADP, bool enSoM, bool enShortTrade, bool enLongTrade, bool enRBRDBDState, bool enTL, bool enSZ, bool alertsOn, string buySoundAlert, string sellSoundAlert, int contractSize, NinjaTrader.NinjaScript.Indicators.AOM_Trading.E_MyOrderType myOrderType, double entryOffset)
		{
			return indicator.aomManualStrategy(input, enGlobalTL, intTLOffset, tLSColor, tLLColor, enADP, enSoM, enShortTrade, enLongTrade, enRBRDBDState, enTL, enSZ, alertsOn, buySoundAlert, sellSoundAlert, contractSize, myOrderType, entryOffset);
		}

		public Indicators.AOM_Trading.aomMarketStrAndBBWaves aomMarketStrAndBBWaves(ISeries<double> input , int iSwingStrength, bool enBarCounting, bool enSwingCounting, bool enSwingVisibility, bool enWaveVisibility, bool enSupportResistanceVisibility, bool enTouchedLine, bool enBrokenLine)
		{
			return indicator.aomMarketStrAndBBWaves(input, iSwingStrength, enBarCounting, enSwingCounting, enSwingVisibility, enWaveVisibility, enSupportResistanceVisibility, enTouchedLine, enBrokenLine);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(ISeries<double> input , int period)
		{
			return indicator.aomMAX(input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(ISeries<double> input , int period)
		{
			return indicator.aomMIN(input, period);
		}

		public Indicators.AOM_Trading.aomRbrDbdSignal aomRbrDbdSignal(ISeries<double> input , bool enLongTrade, bool enShortTrade, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomRbrDbdSignal(input, enLongTrade, enShortTrade, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomSDZones aomSDZones(ISeries<double> input )
		{
			return indicator.aomSDZones(input);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.AOM_Trading.aomADPSignal aomADPSignal(bool enLongTrade, bool enShortTrade, bool enTrendReversal, bool enTrendContinuation, bool enNoiseState, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomADPSignal(Input, enLongTrade, enShortTrade, enTrendReversal, enTrendContinuation, enNoiseState, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomManualStrategy aomManualStrategy(bool enGlobalTL, double intTLOffset, Brush tLSColor, Brush tLLColor, bool enADP, bool enSoM, bool enShortTrade, bool enLongTrade, bool enRBRDBDState, bool enTL, bool enSZ, bool alertsOn, string buySoundAlert, string sellSoundAlert, int contractSize, NinjaTrader.NinjaScript.Indicators.AOM_Trading.E_MyOrderType myOrderType, double entryOffset)
		{
			return indicator.aomManualStrategy(Input, enGlobalTL, intTLOffset, tLSColor, tLLColor, enADP, enSoM, enShortTrade, enLongTrade, enRBRDBDState, enTL, enSZ, alertsOn, buySoundAlert, sellSoundAlert, contractSize, myOrderType, entryOffset);
		}

		public Indicators.AOM_Trading.aomMarketStrAndBBWaves aomMarketStrAndBBWaves(int iSwingStrength, bool enBarCounting, bool enSwingCounting, bool enSwingVisibility, bool enWaveVisibility, bool enSupportResistanceVisibility, bool enTouchedLine, bool enBrokenLine)
		{
			return indicator.aomMarketStrAndBBWaves(Input, iSwingStrength, enBarCounting, enSwingCounting, enSwingVisibility, enWaveVisibility, enSupportResistanceVisibility, enTouchedLine, enBrokenLine);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(int period)
		{
			return indicator.aomMAX(Input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(int period)
		{
			return indicator.aomMIN(Input, period);
		}

		public Indicators.AOM_Trading.aomRbrDbdSignal aomRbrDbdSignal(bool enLongTrade, bool enShortTrade, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomRbrDbdSignal(Input, enLongTrade, enShortTrade, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomSDZones aomSDZones()
		{
			return indicator.aomSDZones(Input);
		}


		
		public Indicators.AOM_Trading.aomADPSignal aomADPSignal(ISeries<double> input , bool enLongTrade, bool enShortTrade, bool enTrendReversal, bool enTrendContinuation, bool enNoiseState, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomADPSignal(input, enLongTrade, enShortTrade, enTrendReversal, enTrendContinuation, enNoiseState, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomManualStrategy aomManualStrategy(ISeries<double> input , bool enGlobalTL, double intTLOffset, Brush tLSColor, Brush tLLColor, bool enADP, bool enSoM, bool enShortTrade, bool enLongTrade, bool enRBRDBDState, bool enTL, bool enSZ, bool alertsOn, string buySoundAlert, string sellSoundAlert, int contractSize, NinjaTrader.NinjaScript.Indicators.AOM_Trading.E_MyOrderType myOrderType, double entryOffset)
		{
			return indicator.aomManualStrategy(input, enGlobalTL, intTLOffset, tLSColor, tLLColor, enADP, enSoM, enShortTrade, enLongTrade, enRBRDBDState, enTL, enSZ, alertsOn, buySoundAlert, sellSoundAlert, contractSize, myOrderType, entryOffset);
		}

		public Indicators.AOM_Trading.aomMarketStrAndBBWaves aomMarketStrAndBBWaves(ISeries<double> input , int iSwingStrength, bool enBarCounting, bool enSwingCounting, bool enSwingVisibility, bool enWaveVisibility, bool enSupportResistanceVisibility, bool enTouchedLine, bool enBrokenLine)
		{
			return indicator.aomMarketStrAndBBWaves(input, iSwingStrength, enBarCounting, enSwingCounting, enSwingVisibility, enWaveVisibility, enSupportResistanceVisibility, enTouchedLine, enBrokenLine);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(ISeries<double> input , int period)
		{
			return indicator.aomMAX(input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(ISeries<double> input , int period)
		{
			return indicator.aomMIN(input, period);
		}

		public Indicators.AOM_Trading.aomRbrDbdSignal aomRbrDbdSignal(ISeries<double> input , bool enLongTrade, bool enShortTrade, bool soundAlertsOn, string fileNameBuySound, string fileNameSellSound)
		{
			return indicator.aomRbrDbdSignal(input, enLongTrade, enShortTrade, soundAlertsOn, fileNameBuySound, fileNameSellSound);
		}

		public Indicators.AOM_Trading.aomSDZones aomSDZones(ISeries<double> input )
		{
			return indicator.aomSDZones(input);
		}

	}
}

#endregion
