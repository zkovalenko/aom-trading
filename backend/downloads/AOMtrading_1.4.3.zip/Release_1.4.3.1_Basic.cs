#region Using declarations
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml.Serialization;
using NinjaTrader.Cbi;
using NinjaTrader.Gui;
using NinjaTrader.Gui.Chart;
using NinjaTrader.Gui.SuperDom;
using NinjaTrader.Gui.Tools;
using NinjaTrader.Data;
using NinjaTrader.NinjaScript;
using NinjaTrader.Core.FloatingPoint;

#endregion



#region NinjaScript generated code. Neither change nor remove.

namespace NinjaTrader.NinjaScript.Indicators
{
	public partial class Indicator : NinjaTrader.Gui.NinjaScript.IndicatorRenderBase
	{
		
		private AOM_Trading.aomSDZones[] cacheaomSDZones;
		private AOM_Trading.aomMAX[] cacheaomMAX;
		private AOM_Trading.aomMIN[] cacheaomMIN;

		
		public AOM_Trading.aomSDZones aomSDZones()
		{
			return aomSDZones(Input);
		}

		public AOM_Trading.aomMAX aomMAX(int period)
		{
			return aomMAX(Input, period);
		}

		public AOM_Trading.aomMIN aomMIN(int period)
		{
			return aomMIN(Input, period);
		}


		
		public AOM_Trading.aomSDZones aomSDZones(ISeries<double> input)
		{
			if (cacheaomSDZones != null)
				for (int idx = 0; idx < cacheaomSDZones.Length; idx++)
					if ( cacheaomSDZones[idx].EqualsInput(input))
						return cacheaomSDZones[idx];
			return CacheIndicator<AOM_Trading.aomSDZones>(new AOM_Trading.aomSDZones(), input, ref cacheaomSDZones);
		}

		public AOM_Trading.aomMAX aomMAX(ISeries<double> input, int period)
		{
			if (cacheaomMAX != null)
				for (int idx = 0; idx < cacheaomMAX.Length; idx++)
					if (cacheaomMAX[idx].Period == period && cacheaomMAX[idx].EqualsInput(input))
						return cacheaomMAX[idx];
			return CacheIndicator<AOM_Trading.aomMAX>(new AOM_Trading.aomMAX(){ Period = period }, input, ref cacheaomMAX);
		}

		public AOM_Trading.aomMIN aomMIN(ISeries<double> input, int period)
		{
			if (cacheaomMIN != null)
				for (int idx = 0; idx < cacheaomMIN.Length; idx++)
					if (cacheaomMIN[idx].Period == period && cacheaomMIN[idx].EqualsInput(input))
						return cacheaomMIN[idx];
			return CacheIndicator<AOM_Trading.aomMIN>(new AOM_Trading.aomMIN(){ Period = period }, input, ref cacheaomMIN);
		}

	}
}

namespace NinjaTrader.NinjaScript.MarketAnalyzerColumns
{
	public partial class MarketAnalyzerColumn : MarketAnalyzerColumnBase
	{
		
		public Indicators.AOM_Trading.aomSDZones aomSDZones()
		{
			return indicator.aomSDZones(Input);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(int period)
		{
			return indicator.aomMAX(Input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(int period)
		{
			return indicator.aomMIN(Input, period);
		}


		
		public Indicators.AOM_Trading.aomSDZones aomSDZones(ISeries<double> input )
		{
			return indicator.aomSDZones(input);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(ISeries<double> input , int period)
		{
			return indicator.aomMAX(input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(ISeries<double> input , int period)
		{
			return indicator.aomMIN(input, period);
		}
	
	}
}

namespace NinjaTrader.NinjaScript.Strategies
{
	public partial class Strategy : NinjaTrader.Gui.NinjaScript.StrategyRenderBase
	{
		
		public Indicators.AOM_Trading.aomSDZones aomSDZones()
		{
			return indicator.aomSDZones(Input);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(int period)
		{
			return indicator.aomMAX(Input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(int period)
		{
			return indicator.aomMIN(Input, period);
		}


		
		public Indicators.AOM_Trading.aomSDZones aomSDZones(ISeries<double> input )
		{
			return indicator.aomSDZones(input);
		}

		public Indicators.AOM_Trading.aomMAX aomMAX(ISeries<double> input , int period)
		{
			return indicator.aomMAX(input, period);
		}

		public Indicators.AOM_Trading.aomMIN aomMIN(ISeries<double> input , int period)
		{
			return indicator.aomMIN(input, period);
		}

	}
}

#endregion
